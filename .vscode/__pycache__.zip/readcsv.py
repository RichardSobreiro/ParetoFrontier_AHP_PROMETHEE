import pandas
df = pandas.read_csv('C:\\Users\\Richard Sobreiro\\hello\\.vscode\\hrdata.csv')
print(df)